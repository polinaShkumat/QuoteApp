package com.example.quoteapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button btn;
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button);
        txt = (TextView)findViewById(R.id.quote);

        String[] motivatingPhrases = {"Believe in yourself", "Never give up", "You can do it", "Keep pushing forward", "Success is within reach"};

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rand = new Random();
                int randomIndex = rand.nextInt(motivatingPhrases.length);
                txt.setText(motivatingPhrases[randomIndex]);
            }
        });

    }
}